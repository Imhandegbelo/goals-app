///============================================================================
/// Name        : caesar_os.cpp
///============================================================================

#include <iostream>
#include"enc_library_bs.hpp"
using namespace std;

int main(int argc, char **argv) {
    // holds provided encrypted and decrypted filenames
    string encrypted_file = argv[1];
    string decrypted_file = argv[2];
    // Creates the key variable
    int key;

    // Calls character_count the encrypted_file
    character_count(encrypted_file);

    cout << "Enter the key you would like to use:  ";
    // Takes user input and sends to int key
    cin >> key;
    ///Calling the decrypt function with all command line arguments, and user input of key
    decrypt(encrypted_file, decrypted_file, key);
}
