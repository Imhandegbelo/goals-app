//============================================================================
// Name        : enc_library_os.cpp
//============================================================================

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

/** Converts lowercase character to uppercase.
 * @author
 * @param[in] Character to change (char)
 * @return Input character's uppercase.
 * @date 13/01/2024
 * @test to_upper('g') -> 'G'
 * @test to_upper('H') -> 'H'
 * @test to_upper('3') -> '3'
 * @test to_upper('B') -> 'B'
 * @test to_upper('T') -> 'T'
 * @test to_upper('q') -> 'Q'
 */

char to_upper(char input)
{
    if (input >= 97 && input <= 122)
        return input - 32;
    else
        return input;
}

/** Checks that a given character is an alphabet.
 * @author 
 * @param[in] Character to check (char)
 * @return True if alphabet, false otherwise.
 * @date 13/01/2024
 * @test is_alpha('c') -> true
 * @test is_alpha('K') -> true
 * @test is_alpha(''') -> false
 * @test is_alpha('/0') -> false
 * @test is_alpha('6') -> false
 */

bool is_alpha(char input)
{
    return ((input >= 65 && input <= 90) || (input >= 97 && input <= 122));
}

/** Checks that given character is uppercase.
 * @author 
 * @param[in] input Character to check (char)
 * @return True if uppercase, false otherwise.
 * @date 13/01/2024
 * @test is_upper('n') -> false
 * @test is_upper(''') -> false
 * @test is_upper('S') -> true
 * @test is_upper('C') -> true
 * @test is_upper('5') -> false
 */

bool is_upper(char input)
{
    return (input >= 97 && input <= 122);
}

/** Finds the most frequent character.
 * @author 
 * @date 13/01/2024
 * @param[in] freq_count array of character occurrences (int[])
 * @return Returns max, the value in freq_count with the biggest value
 * @test *freq_count[26] = {1, 12, 1, 9, 53, 134, 23, 504} * max_index(freq_count) -> max = 504
 * @test *freq_count[26] = {1,0} * max_index(freq_count) -> max = 1
 * @test *freq_count[26] = {} * max_index(freq_count) -> Error (Does not build)
 * @test max_index(freq_count[]) -> Error (Does not build)
 * @test max_index(a_count[]) -> Error (Does not build)
 */

int max_index(int freq_count[]){
    int max = 0;
    int i;

    for (i = 0; i != 26; i++){
        // if current value is greater than max, assign it to max
        if (max < freq_count[i])
            max = freq_count[i];
    }
    return max;
}

/** Carries out analysis on the encrypted test
 * @author 
 * @param[in] freq_count Integer array of character occurrences (int[])
 * @return Void
 * @date 13/01/2024
 * @test freq_count[26] = {1, 12, 1, 9, 53, 134, 23, 504} * print_analysis_array(freq_count) -> Suggested Key : 12
 */

void print_analysis_array(int freq_count[]){
    int i;

    // Prints out all letters and their frequency in the encrypted text
    for (i = 0; i != 26; i++){
        cout << char(i + 'A') << " occurs:" << freq_count[i] << " times"
             << endl;
    }

    for (i = 0; i != 26; i++){
        // if max_index is current index, assume it to be E
        if (max_index(freq_count) == freq_count[i]){
            cout << "The most frequent letter is: " << char(i + 'A')
                 << " with a count of: " << freq_count[i] << endl;
            cout
                    << "If we assume this to be 'E' when decrypted, the most likely key is: "
                    << (char('A' + i) - 'E') << endl;
        }
    }
}

/** Counts the frequency of the characters in the given file.
 * @author
 * @param[in] encrypted_file Encypted Filename (std::string)
 * @param[out] freq_count Integer array of character occurrences (int[])
 * @date 13/01/2024
 * @test Tests in testing document
 */

void character_count(std::string encrypted_file){
    string line;
    int freq_count[26] = { 0 };
    ifstream InputFile(encrypted_file);

    // If opening the file was successful else inform user
    if (InputFile.is_open()){
        // Loops through file line by line
        while (getline(InputFile, line)){
            unsigned int i;
            unsigned int j;

            // Ascii value for uppercase and lowercase a
            int ascii_upper = 97;
            int ascii_lower = 65;

            for (i = 0; i < 26; i++){
                for (j = 0; j <= line.length(); j++){
                    // Checks both upper and lower case letters
                    if (line[j] == ascii_upper || line[j] == ascii_lower){
                        // Increments by one whenever a character is counted
                        freq_count[i] += 1;
                    }
                }
                // Increments through the uppercase or lowercase alphabet
                ascii_upper += 1;
                ascii_lower += 1;
            }
        }
        // Calls print_analysis_array with the occurences in freq_count
        print_analysis_array(freq_count);
        // Closes the file stream
        InputFile.close();
    }
    else{
        cout << "Ooop! Encrypted Text file not found. Exiting ..." << endl;
        exit(1);
    }
}

/** Decrypts the given .txt file line by line
 * @author 
 * @param[in] encrypted_file Encrypted Filename (std::string)
 * @param[in] decrypted_file Decrypted Filename (std::string)
 * @param[in] key Decryption Key Chosen by user (int)
 * @param[out] plain Plain text string to write to file (string)
 * @param[out] decrypted_file Text file of decrypted text
 * @date 13/01/2024
 * @test Tests in testing Documentation
 */

void decrypt(std::string encrypted_file, std::string decrypted_file, int key)
{
    string line;
    string plain;

    // Opens encrypted file and creates the decrypted file
    ifstream InputFile(encrypted_file);
    ofstream OutputFile(decrypted_file);

    // Loops line by line
    while (getline(InputFile, line)){
        unsigned int i;
        int ascii_z;

        // Iterates through the line until the end of line
        for (i = 0; i < line.length(); ++i){
            if (is_alpha(line[i]) != 0){
                ascii_z = 90;
                if (is_upper(line[i]) != 0){
                    ascii_z = 122;
                }
                plain += (line[i] - key - ascii_z) % 26 + ascii_z;
            }
            else{
                plain += line[i];
            }
        }
        // Adds a new line to 'plain' after each line
        plain += '\n';
    }

    // Displays a sample decrypted text to the user.
    cout << "Here is a sample of the decrypted text" << endl;
    cout << '"';
    for (int i = 0; i < 150; i++){
        cout << plain[i];
    }
    cout << '"' << endl;

    cout << "Would you like to continue with the current key? (y/n)" << endl;
    char response;
    cin >> response;
    if (response == 'y'){
        // Completes writing decrpyted text to the output text file
        OutputFile << plain;
        cout << "The remaining text has been decrypted using the key: " << key << " and written to the file: " << decrypted_file << endl;
    }
    else{
        cout << "Would you like to try another key? (y/n)" << endl;
        cin >> response;
        if (response != 'y'){
            // Exits if user chooses 'n' or something else
            exit(1);
        }
        else{
            cout << "What key would you like to try: ";
            cin >> key;
            // Reruns the function with the new key
            decrypt(encrypted_file, decrypted_file, key);
        }
    }

    // Close the files
    InputFile.close();
    OutputFile.close();
}
